package com.banking.controller;

import com.banking.model.Account;
import com.banking.model.PersonalAccount;
import com.banking.model.BusinessAccount;
import java.util.HashMap;

public class AccountController {
    private HashMap<String, Account> accounts = new HashMap<>();

    public void createPersonalAccount(String accountNumber, String accountHolderName, double initialDeposit) {
        accounts.put(accountNumber, new PersonalAccount(accountNumber, accountHolderName, initialDeposit));
    }

    public void createBusinessAccount(String accountNumber, String accountHolderName, double initialDeposit) {
        accounts.put(accountNumber, new BusinessAccount(accountNumber, accountHolderName, initialDeposit));
    }

    public void editAccountDetails(String accountNumber, String newAccountHolderName) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            account.setAccountHolderName(newAccountHolderName);
        }
    }

    public void closeAccount(String accountNumber) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            account.closeAccount();
            accounts.remove(accountNumber);
        }
    }
}

