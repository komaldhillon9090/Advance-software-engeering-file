package com.banking.controller;

import com.banking.model.AccountServices;
import java.util.HashMap; // Import the HashMap class

public class AccountServiceController {
    private HashMap<String, AccountServices> accountServicesMap = new HashMap<>();

    public void requestCheckbook(String accountNumber) {
        AccountServices services = accountServicesMap.getOrDefault(accountNumber, new AccountServices());
        services.requestCheckbook();
        accountServicesMap.put(accountNumber, services);
    }

    public void requestCard(String accountNumber) {
        AccountServices services = accountServicesMap.getOrDefault(accountNumber, new AccountServices());
        services.requestCard();
        accountServicesMap.put(accountNumber, services);
    }

    public AccountServices getAccountServices(String accountNumber) {
        return accountServicesMap.get(accountNumber);
    }
}
