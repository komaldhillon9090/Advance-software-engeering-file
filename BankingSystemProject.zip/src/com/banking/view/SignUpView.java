package com.banking.view;

import com.banking.utils.LocalStorageManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.HashMap;
import java.util.Random;

public class SignUpView extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JTextField emailField;
    private JComboBox<String> accountTypeComboBox;
    private JTextField openingBalanceField;
    private JTextField captchaField;
    private JLabel captchaLabel;
    private JButton signUpButton;
    private JFrame parentFrame;
    private String generatedCaptcha;

    public SignUpView(JFrame parentFrame) {
        this.parentFrame = parentFrame;

        // Set layout for the sign-up panel
        setLayout(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.gridx = 0;
        gbc.gridy = 0;

        // Initialize components
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        emailField = new JTextField(20);
        accountTypeComboBox = new JComboBox<>(new String[]{"Personal", "Business"});
        openingBalanceField = new JTextField(20);
        captchaField = new JTextField(10);
        signUpButton = new JButton("Sign Up");

        // Generate and display CAPTCHA
        generatedCaptcha = generateCaptcha();
        captchaLabel = new JLabel("CAPTCHA: " + generatedCaptcha);

        // Add components to the panel
        add(new JLabel("Username:"), gbc);
        gbc.gridx = 1;
        add(usernameField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        add(new JLabel("Password:"), gbc);
        gbc.gridx = 1;
        add(passwordField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 2;
        add(new JLabel("Email:"), gbc);
        gbc.gridx = 1;
        add(emailField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 3;
        add(new JLabel("Account Type:"), gbc);
        gbc.gridx = 1;
        add(accountTypeComboBox, gbc);
        gbc.gridx = 0;
        gbc.gridy = 4;
        add(new JLabel("Opening Balance:"), gbc);
        gbc.gridx = 1;
        add(openingBalanceField, gbc);
        gbc.gridx = 0;
        gbc.gridy = 5;
        add(captchaLabel, gbc);
        gbc.gridx = 1;
        add(captchaField, gbc);
        gbc.gridx = 1;
        gbc.gridy = 6;
        add(signUpButton, gbc);

        // Add action listener for sign-up button
        signUpButton.addActionListener(this::signUp);
    }

    private String generateCaptcha() {
        Random random = new Random();
        int captcha = random.nextInt(9000) + 1000;  // Generate a random 4-digit number
        return String.valueOf(captcha);
    }

    private void signUp(ActionEvent e) {
        // Validate CAPTCHA
        if (!captchaField.getText().equals(generatedCaptcha)) {
            JOptionPane.showMessageDialog(this, "CAPTCHA does not match. Please try again.");
            // Regenerate CAPTCHA
            generatedCaptcha = generateCaptcha();
            captchaLabel.setText("CAPTCHA: " + generatedCaptcha);
            return;
        }

        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String email = emailField.getText();
        String accountType = (String) accountTypeComboBox.getSelectedItem();
        String openingBalanceStr = openingBalanceField.getText();
        double openingBalance;

        // Validate the opening balance input
        try {
            openingBalance = Double.parseDouble(openingBalanceStr);
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter a valid amount for the opening balance.");
            return;
        }

        // Generate a random account number
        Random random = new Random();
        int accountNumber = random.nextInt(900000) + 100000;

        // Store user data in a HashMap
        HashMap<String, Object> userData = new HashMap<>();
        userData.put("username", username);
        userData.put("password", password);
        userData.put("email", email);
        userData.put("accountType", accountType);
        userData.put("accountNumber", accountNumber);
        userData.put("balance", openingBalance);

        // Save data using LocalStorageManager
        LocalStorageManager.save("userDetails", userData);

        JOptionPane.showMessageDialog(this, "Sign up successful! Account Number: " + accountNumber);

        // Switch to DashboardView, passing both the parentFrame and the userData
        parentFrame.getContentPane().removeAll();
        parentFrame.getContentPane().add(new DashboardView(parentFrame, userData));
        parentFrame.revalidate();
        parentFrame.repaint();
    }
}
