package com.banking.model;

import java.util.Date;

public class Transaction {
    private String transactionId;
    private String accountNumber;
    private double amount;
    private Date date;

    public Transaction(String transactionId, String accountNumber, double amount) {
        this.transactionId = transactionId;
        this.accountNumber = accountNumber;
        this.amount = amount;
        this.date = new Date();
    }

    public String getTransactionId() { return transactionId; }
    public String getAccountNumber() { return accountNumber; }
    public double getAmount() { return amount; }
    public Date getDate() { return date; }
}

