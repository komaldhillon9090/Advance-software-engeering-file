package com.banking.controller;

import com.banking.model.Transaction;
import com.banking.model.Account;
import java.util.ArrayList;
import java.util.HashMap;

public class TransactionController {
    private HashMap<String, Account> accounts;
    private ArrayList<Transaction> transactions = new ArrayList<>();

    public TransactionController(HashMap<String, Account> accounts) {
        this.accounts = accounts;
    }

    public void deposit(String accountNumber, double amount) {
        Account account = accounts.get(accountNumber);
        if (account != null) {
            account.deposit(amount);
            transactions.add(new Transaction("TXN" + transactions.size(), accountNumber, amount));
        }
    }

    public void withdraw(String accountNumber, double amount) {
        Account account = accounts.get(accountNumber);
        if (account != null && account.getBalance() >= amount) {
            account.withdraw(amount);
            transactions.add(new Transaction("TXN" + transactions.size(), accountNumber, -amount));
        }
    }

    public void transfer(String fromAccount, String toAccount, double amount) {
        withdraw(fromAccount, amount);
        deposit(toAccount, amount);
    }

    public ArrayList<Transaction> getTransactionHistory(String accountNumber) {
        ArrayList<Transaction> history = new ArrayList<>();
        for (Transaction txn : transactions) {
            if (txn.getAccountNumber().equals(accountNumber)) {
                history.add(txn);
            }
        }
        return history;
    }
}
