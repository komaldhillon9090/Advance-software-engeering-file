package com.banking.view;

import com.banking.utils.LocalStorageManager;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.HashMap;

public class DashboardView extends JPanel {

    private JButton checkAccountButton;
    private JButton depositButton;
    private JButton withdrawButton;
    private JButton transferButton;
    private JButton requestCheckbookButton;
    private JButton requestCardButton;
    private JButton viewTransactionHistoryButton;
    private JButton logoutButton;

    private HashMap<String, Object> userData;
    private JFrame parentFrame;
    private ArrayList<String> transactionHistory;

    public DashboardView(JFrame parentFrame, HashMap<String, Object> userData) {
        this.userData = userData;
        this.parentFrame = parentFrame;

        // Retrieve and safely cast the transaction history from LocalStorageManager
        Object retrievedData = LocalStorageManager.retrieve("transactionHistory");
        if (retrievedData instanceof ArrayList<?>) {
            this.transactionHistory = new ArrayList<>();
            for (Object obj : (ArrayList<?>) retrievedData) {
                if (obj instanceof String) {
                    this.transactionHistory.add((String) obj);
                } else {
                    System.out.println("Warning: Invalid type in transaction history, expected String.");
                }
            }
        } else {
            this.transactionHistory = new ArrayList<>();
        }

        // Set margin around the dashboard
        setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20)); // 20px padding on each side

        // Set the layout for the dashboard panel
        setLayout(new GridLayout(8, 1, 10, 10)); // 8 rows, 1 column, with padding of 10 pixels

        // Initialize buttons for each action and style them as cards
        checkAccountButton = createCardButton("Check Account Details");
        depositButton = createCardButton("Deposit Money");
        withdrawButton = createCardButton("Withdraw Money");
        transferButton = createCardButton("Transfer Funds");
        requestCheckbookButton = createCardButton("Request Checkbook");
        requestCardButton = createCardButton("Request Card");
        viewTransactionHistoryButton = createCardButton("View Transaction History");
        logoutButton = createCardButton("Logout");

        // Add action listeners to the buttons
        checkAccountButton.addActionListener(e -> JOptionPane.showMessageDialog(DashboardView.this, String.format(
                "Account Number: %s\nEmail: %s\nAccount Type: %s\nBalance: $%.2f",
                userData.get("accountNumber"),
                userData.get("email"),
                userData.get("accountType"),
                Double.parseDouble(userData.get("balance").toString())  // Correctly cast the balance to double
        )));

        depositButton.addActionListener(e -> {
            String amountStr = JOptionPane.showInputDialog(DashboardView.this, "Enter amount to deposit:");
            if (amountStr != null && !amountStr.isEmpty()) {
                try {
                    double amount = Double.parseDouble(amountStr);
                    double currentBalance = (double) userData.get("balance");
                    double newBalance = currentBalance + amount;
                    userData.put("balance", newBalance);
                    transactionHistory.add("Deposited: $" + amount);
                    LocalStorageManager.updateData("userDetails", userData);
                    LocalStorageManager.updateData("transactionHistory", transactionHistory);
                    JOptionPane.showMessageDialog(DashboardView.this, "Deposited: $" + amount + "\nNew Balance: $" + newBalance);
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(DashboardView.this, "Please enter a valid amount.");
                }
            }
        });

        withdrawButton.addActionListener(e -> {
            if (!verifyTransactionPin()) return;

            String amountStr = JOptionPane.showInputDialog(DashboardView.this, "Enter amount to withdraw:");
            if (amountStr != null && !amountStr.isEmpty()) {
                try {
                    double amount = Double.parseDouble(amountStr);
                    double currentBalance = (double) userData.get("balance");
                    if (amount > currentBalance) {
                        JOptionPane.showMessageDialog(DashboardView.this, "Insufficient funds.");
                    } else {
                        double newBalance = currentBalance - amount;
                        userData.put("balance", newBalance);
                        transactionHistory.add("Withdrew: $" + amount);
                        LocalStorageManager.updateData("userDetails", userData);
                        LocalStorageManager.updateData("transactionHistory", transactionHistory);
                        JOptionPane.showMessageDialog(DashboardView.this, "Withdrew: $" + amount + "\nNew Balance: $" + newBalance);
                    }
                } catch (NumberFormatException ex) {
                    JOptionPane.showMessageDialog(DashboardView.this, "Please enter a valid amount.");
                }
            }
        });

        transferButton.addActionListener(e -> {
            if (!verifyTransactionPin()) return;

            String recipientAccountStr = JOptionPane.showInputDialog(DashboardView.this, "Enter recipient's account number:");
            if (recipientAccountStr != null && !recipientAccountStr.isEmpty()) {
                String amountStr = JOptionPane.showInputDialog(DashboardView.this, "Enter amount to transfer:");
                if (amountStr != null && !amountStr.isEmpty()) {
                    try {
                        double amount = Double.parseDouble(amountStr);
                        double currentBalance = (double) userData.get("balance");
                        if (amount > currentBalance) {
                            JOptionPane.showMessageDialog(DashboardView.this, "Insufficient funds.");
                        } else {
                            double newBalance = currentBalance - amount;
                            userData.put("balance", newBalance);
                            transactionHistory.add("Transferred: $" + amount + " to account " + recipientAccountStr);
                            LocalStorageManager.updateData("userDetails", userData);
                            LocalStorageManager.updateData("transactionHistory", transactionHistory);
                            JOptionPane.showMessageDialog(DashboardView.this, "Transferred: $" + amount + "\nNew Balance: $" + newBalance);
                        }
                    } catch (NumberFormatException ex) {
                        JOptionPane.showMessageDialog(DashboardView.this, "Please enter a valid amount.");
                    }
                }
            }
        });

        requestCheckbookButton.addActionListener(e -> JOptionPane.showMessageDialog(DashboardView.this, "Checkbook request submitted."));

        requestCardButton.addActionListener(e -> JOptionPane.showMessageDialog(DashboardView.this, "Card request submitted."));

        viewTransactionHistoryButton.addActionListener(e -> {
            StringBuilder history = new StringBuilder("Transaction History:\n");
            for (String transaction : transactionHistory) {
                history.append(transaction).append("\n");
            }
            JOptionPane.showMessageDialog(DashboardView.this, history.toString());
        });

        logoutButton.addActionListener(e -> {
            // // Clear local storage content
            // LocalStorageManager.remove("userDetails");
            // LocalStorageManager.remove("transactionHistory");
            // LocalStorageManager.remove("transactionPin");

            // Go back to the LoginView
            parentFrame.getContentPane().removeAll();
            parentFrame.getContentPane().add(new LoginView(parentFrame));
            parentFrame.revalidate();
            parentFrame.repaint();
        });

        // Add buttons to the dashboard panel
        add(checkAccountButton);
        add(depositButton);
        add(withdrawButton);
        add(transferButton);
        add(requestCheckbookButton);
        add(requestCardButton);
        add(viewTransactionHistoryButton);
        add(logoutButton);
    }

    // Helper method to create a button with card-like styling
    private JButton createCardButton(String text) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setFont(new Font("Arial", Font.PLAIN, 16));
        button.setPreferredSize(new Dimension(200, 50));
        return button;
    }

    // Helper method to verify the transaction PIN
    private boolean verifyTransactionPin() {
        String storedPin = (String) LocalStorageManager.retrieve("transactionPin");

        if (storedPin == null) {
            String newPin = JOptionPane.showInputDialog(this, "No transaction PIN found. Please create a new 4-digit PIN:");
            if (newPin == null || newPin.length() != 4 || !newPin.matches("\\d{4}")) {
                JOptionPane.showMessageDialog(this, "Invalid PIN. Please enter a 4-digit PIN.");
                return false;
            }
            LocalStorageManager.save("transactionPin", newPin);
            JOptionPane.showMessageDialog(this, "Transaction PIN created successfully!");
            return true;
        } else {
            String enteredPin = JOptionPane.showInputDialog(this, "Enter your 4-digit transaction PIN:");
            if (enteredPin == null || !enteredPin.equals(storedPin)) {
                JOptionPane.showMessageDialog(this, "Incorrect PIN. Transaction canceled.");
                return false;
            }
            return true;
        }
    }
}
