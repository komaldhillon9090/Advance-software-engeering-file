package com.banking.view;

import com.banking.utils.LocalStorageManager;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;

public class LoginView extends JPanel {
    private JTextField usernameField;
    private JPasswordField passwordField;
    private JButton loginButton;
    private JButton signUpButton;
    private JFrame parentFrame;

    public LoginView(JFrame parentFrame) {
        this.parentFrame = parentFrame;

        // Initialize components
        usernameField = new JTextField(20);
        passwordField = new JPasswordField(20);
        loginButton = new JButton("Login");
        signUpButton = new JButton("Sign Up");

        // Add action listener to the login button
        loginButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                login();
            }
        });

        signUpButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                parentFrame.getContentPane().removeAll();
                parentFrame.getContentPane().add(new SignUpView(parentFrame));
                parentFrame.revalidate();
                parentFrame.repaint();
            }
        });

        // Set layout and add components to the panel
        setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));
        add(new JLabel("Username:"));
        add(usernameField);
        add(new JLabel("Password:"));
        add(passwordField);
        add(loginButton);
        add(signUpButton);
    }

    private void login() {
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());

        // Retrieve stored user details
        HashMap<String, Object> storedUserData = (HashMap<String, Object>) LocalStorageManager.retrieve("userDetails");

        if (storedUserData != null) {
            String storedUsername = (String) storedUserData.get("username");
            String storedPassword = (String) storedUserData.get("password");

            // Authenticate user
            if (username.equals(storedUsername) && password.equals(storedPassword)) {
                JOptionPane.showMessageDialog(this, "Login successful!");

                // Switch to DashboardView with the stored user data
                parentFrame.getContentPane().removeAll();
                parentFrame.getContentPane().add(new DashboardView(parentFrame, storedUserData));
                parentFrame.revalidate();
                parentFrame.repaint();
            } else {
                JOptionPane.showMessageDialog(this, "Invalid username or password.");
            }
        } else {
            JOptionPane.showMessageDialog(this, "No user found. Please sign up.");
        }
    }
}
