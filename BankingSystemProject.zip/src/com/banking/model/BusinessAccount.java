package com.banking.model;

public class BusinessAccount extends Account {
    public BusinessAccount(String accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    @Override
    public void closeAccount() {
        balance = 0;
        System.out.println("Business account closed.");
    }
}
