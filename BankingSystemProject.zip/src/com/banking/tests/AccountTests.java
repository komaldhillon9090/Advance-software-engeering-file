package com.banking.tests;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertThrows;

import org.junit.Before;
import org.junit.Test;

import com.banking.model.Account;
import com.banking.model.PersonalAccount;

public class AccountTests {

    private Account account;

    @Before
    public void setUp() {
        // Set up a test account before each test
        account = new PersonalAccount("1234567890", "John Doe", 1000.00);
    }

    @Test
    public void testAccountCreation() {
        System.out.println("Running testAccountCreation...");
        // Test that an account is created correctly
        assertNotNull("Account should not be null", account);
        assertEquals("Account number should match", "1234567890", account.getAccountNumber());
        assertEquals("Account holder name should match", "John Doe", account.getAccountHolderName());
        assertEquals("Initial balance should match", 1000.00, account.getBalance(), 0.001);
        System.out.println("testAccountCreation passed.");
    }

    @Test
    public void testDeposit() {
        System.out.println("Running testDeposit...");
        // Test the deposit functionality
        account.deposit(500.00);
        assertEquals("Balance should be updated after deposit", 1500.00, account.getBalance(), 0.001);
        System.out.println("testDeposit passed.");
    }

    @Test
    public void testWithdraw() {
        System.out.println("Running testWithdraw...");
        // Test the withdraw functionality
        account.withdraw(300.00);
        assertEquals("Balance should be updated after withdrawal", 700.00, account.getBalance(), 0.001);
        System.out.println("testWithdraw passed.");
    }

    @Test
    public void testWithdrawInsufficientFunds() {
        System.out.println("Running testWithdrawInsufficientFunds...");
        // Test withdrawal with insufficient funds
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            account.withdraw(1200.00);
        });
        assertEquals("Insufficient balance", exception.getMessage());
        System.out.println("testWithdrawInsufficientFunds passed.");
    }

    @Test
    public void testGetAccountDetails() {
        System.out.println("Running testGetAccountDetails...");
        // Test retrieving account details
        String expectedDetails = "Account Number: 1234567890\n" +
                                 "Account Holder: John Doe\n" +
                                 "Balance: 1000.00";
        assertEquals("Account details should match", expectedDetails, account.getAccountDetails());
        System.out.println("testGetAccountDetails passed.");
    }
}
