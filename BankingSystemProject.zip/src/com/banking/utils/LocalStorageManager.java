package com.banking.utils;

import java.util.HashMap;

public class LocalStorageManager {
    private static HashMap<String, Object> storage = new HashMap<>();

    public static void save(String key, Object data) {
        storage.put(key, data);
    }

    public static Object retrieve(String key) {
        return storage.get(key);
    }

    public static void updateData(String key, Object data) {
        storage.put(key, data);
    }
}
