package com.banking.model;

public class AccountServices {
    private boolean checkbookRequested;
    private boolean cardRequested;

    public AccountServices() {
        this.checkbookRequested = false;
        this.cardRequested = false;
    }

    public void requestCheckbook() {
        this.checkbookRequested = true;
    }

    public void requestCard() {
        this.cardRequested = true;
    }

    public boolean isCheckbookRequested() { return checkbookRequested; }
    public boolean isCardRequested() { return cardRequested; }
}

