package com.banking.model;

public class PersonalAccount extends Account {
    public PersonalAccount(String accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    @Override
    public void closeAccount() {
        balance = 0;
        System.out.println("Personal account closed.");
    }
}
