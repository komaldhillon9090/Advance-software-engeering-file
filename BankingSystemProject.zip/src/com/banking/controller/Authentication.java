package com.banking.controller;

import com.banking.model.User;
import com.banking.utils.EncryptionUtils;
import java.util.HashMap;

public class Authentication {
    private HashMap<String, User> users;

    public Authentication(HashMap<String, User> users) {
        this.users = users;
    }

    public boolean authenticate(String username, String password) {
        User user = users.get(username);
        if (user != null) {
            String encryptedPassword = EncryptionUtils.encryptPassword(password);
            return user.getPassword().equals(encryptedPassword);
        }
        return false;
    }
}
