package com.banking.view;

public class TransactionView {
    
}
